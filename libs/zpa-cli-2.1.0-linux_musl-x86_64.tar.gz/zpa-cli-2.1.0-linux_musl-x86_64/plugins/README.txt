Put your custom plugins in this directory.

Follow the instructions at https://github.com/felipebz/zpa/wiki/Create-a-plugin-with-custom-rules to create a custom plugin with additional rules.